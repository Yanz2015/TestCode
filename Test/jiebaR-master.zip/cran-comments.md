## Test environments

* macOS R-3.3.1
* Ubuntu 14.04 (on travis-ci), R 3.3.1
* Windows 10 R-3.3.1 and R-devel

## R CMD check results

0 errors | 0 warnings | 1 note on macOS and Windows

* checking CRAN incoming feasibility ... NOTE

Maintainer: ‘Qin Wenfeng <mail@qinwenfeng.com>’

License components with restrictions and base license permitting such:

  MIT + file LICENSE

File 'LICENSE':

  YEAR: 2014-2016

  COPYRIGHT HOLDER: Qin Wenfeng
